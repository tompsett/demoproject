## webapp-demo

## Usage

You must have:

* Ruby (tested on 2.0.0)
* Ruby Gems
* Bundler

To run:

```
bundle install
bundle exec rails server
```

And then point your browser to [http://localhost:3000](http://localhost:3000)

## Acknowledgements

This is based on the [official Ruby on Rails tutorial](http://guides.rubyonrails.org/getting_started.html).
